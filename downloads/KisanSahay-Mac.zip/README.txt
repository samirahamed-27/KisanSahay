🌾 KisanSahay — Accessible Farmers Loan & Scheme Portal
======================================================

How to install on Mac:
1. Drag 'KisanSahay.app' into your Mac's Applications folder or onto your Desktop.
2. Double-click 'KisanSahay.app' to launch the app!
3. You can also drag it onto your Mac Dock for instant 1-click access.

Enjoy fast, offline-ready access to farmer schemes, loan calculators, and document vault!
