🌾 KisanSahay — Accessible Farmers Loan & Scheme Portal
======================================================

How to open on Mac:
1. Double-click 'KisanSahay.app' to launch the app in its own window!
2. Or double-click 'Open-KisanSahay.html' / 'KisanSahay.webloc' to open directly in your browser.
3. You can also drag 'KisanSahay.app' into your Applications folder or Dock.

Enjoy fast, offline-ready access to farmer schemes, loan calculators, and document vault!
