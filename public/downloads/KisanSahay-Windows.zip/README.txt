🌾 KisanSahay — Accessible Farmers Loan & Scheme Portal
======================================================

How to install on Windows PC:
1. Extract this zip file.
2. Drag 'KisanSahay.url' to your Desktop.
3. Double-click to launch KisanSahay anytime!
