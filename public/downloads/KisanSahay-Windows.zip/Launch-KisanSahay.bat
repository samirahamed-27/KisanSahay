@echo off
title KisanSahay Launcher
start http://localhost:3000
